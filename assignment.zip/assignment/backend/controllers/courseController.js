const Course = require("models/Course.js");

// Create a new course
const createCourse = async (req, res) => {
    const { title, description, instructor, duration } = req.body;

    try {
        // Create a new course in the database
        const newCourse = await Course.create({
            title,
            description,
            instructor,
            duration,
        });

        res.status(201).json({ message: "Course created successfully!", course: newCourse });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to create course." });
    }
};

// Get all courses
const getAllCourses = async (req, res) => {
    try {
        const courses = await Course.findAll();
        res.status(200).json(courses);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch courses." });
    }
};

// Get a specific course by ID
const getCourseById = async (req, res) => {
    const { id } = req.params;

    try {
        const course = await Course.findOne({ where: { id } });
        if (!course) {
            return res.status(404).json({ message: "Course not found." });
        }

        res.status(200).json(course);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch course details." });
    }
};

// Update a course by ID
const updateCourse = async (req, res) => {
    const { id } = req.params;
    const { title, description, instructor, duration } = req.body;

    try {
        const course = await Course.findOne({ where: { id } });
        if (!course) {
            return res.status(404).json({ message: "Course not found." });
        }

        // Update the course
        await course.update({ title, description, instructor, duration });
        res.status(200).json({ message: "Course updated successfully!", course });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to update course." });
    }
};

// Delete a course by ID
const deleteCourse = async (req, res) => {
    const { id } = req.params;

    try {
        const course = await Course.findOne({ where: { id } });
        if (!course) {
            return res.status(404).json({ message: "Course not found." });
        }

        // Delete the course
        await course.destroy();
        res.status(200).json({ message: "Course deleted successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to delete course." });
    }
};

module.exports = { createCourse, getAllCourses, getCourseById, updateCourse, deleteCourse };
