const Student = require("models/Student.js");

// Create a new student
const createStudent = async (req, res) => {
    const { name, email, courseId } = req.body;

    try {
        // Create a new student
        const newStudent = await Student.create({
            name,
            email,
            courseId,
        });

        res.status(201).json({ message: "Student created successfully!", student: newStudent });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to create student." });
    }
};

// Get all students
const getAllStudents = async (req, res) => {
    try {
        const students = await Student.findAll();
        res.status(200).json(students);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch students." });
    }
};

// Get a student by ID
const getStudentById = async (req, res) => {
    const { id } = req.params;

    try {
        const student = await Student.findOne({ where: { id } });
        if (!student) {
            return res.status(404).json({ message: "Student not found." });
        }

        res.status(200).json(student);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch student details." });
    }
};

// Update a student by ID
const updateStudent = async (req, res) => {
    const { id } = req.params;
    const { name, email, courseId } = req.body;

    try {
        const student = await Student.findOne({ where: { id } });
        if (!student) {
            return res.status(404).json({ message: "Student not found." });
        }

        // Update the student
        await student.update({ name, email, courseId });
        res.status(200).json({ message: "Student updated successfully!", student });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to update student." });
    }
};

// Delete a student by ID
const deleteStudent = async (req, res) => {
    const { id } = req.params;

    try {
        const student = await Student.findOne({ where: { id } });
        if (!student) {
            return res.status(404).json({ message: "Student not found." });
        }

        // Delete the student
        await student.destroy();
        res.status(200).json({ message: "Student deleted successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to delete student." });
    }
};

module.exports = { createStudent, getAllStudents, getStudentById, updateStudent, deleteStudent };
