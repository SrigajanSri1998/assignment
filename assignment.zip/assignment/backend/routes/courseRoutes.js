const express = require("express");
const { authenticateUser, authorizeAdmin } = require("../middleware/authMiddleware");
const { createCourse, getAllCourses, getCourseById, updateCourse, deleteCourse } = require("../controllers/courseController");
const router = express.Router();

// Create a new course (admin only)
router.post("/courses", authenticateUser, authorizeAdmin, createCourse);

// Get all courses
router.get("/courses", getAllCourses);

// Get a course by ID
router.get("/courses/:id", getCourseById);

// Update a course by ID (admin only)
router.put("/courses/:id", authenticateUser, authorizeAdmin, updateCourse);

// Delete a course by ID (admin only)
router.delete("/courses/:id", authenticateUser, authorizeAdmin, deleteCourse);

module.exports = router;
