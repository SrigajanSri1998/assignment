const Enrollment = require("models/Enrollment.js");
const Student = require("models/Student.js");
const Course = require("models/Course.js");

// Create a new enrollment
const createEnrollment = async (req, res) => {
    const { studentId, courseId } = req.body;

    try {
        // Check if student and course exist
        const student = await Student.findByPk(studentId);
        const course = await Course.findByPk(courseId);
        
        if (!student || !course) {
            return res.status(404).json({ message: "Student or Course not found." });
        }

        // Create a new enrollment
        const newEnrollment = await Enrollment.create({
            studentId,
            courseId,
        });

        res.status(201).json({ message: "Enrollment created successfully!", enrollment: newEnrollment });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to create enrollment." });
    }
};

// Get all enrollments
const getAllEnrollments = async (req, res) => {
    try {
        const enrollments = await Enrollment.findAll({
            include: [Student, Course]  // Include associated student and course details
        });
        res.status(200).json(enrollments);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch enrollments." });
    }
};

// Get an enrollment by ID
const getEnrollmentById = async (req, res) => {
    const { id } = req.params;

    try {
        const enrollment = await Enrollment.findOne({
            where: { id },
            include: [Student, Course]
        });
        
        if (!enrollment) {
            return res.status(404).json({ message: "Enrollment not found." });
        }

        res.status(200).json(enrollment);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to fetch enrollment details." });
    }
};

// Update an enrollment by ID
const updateEnrollment = async (req, res) => {
    const { id } = req.params;
    const { studentId, courseId } = req.body;

    try {
        const enrollment = await Enrollment.findOne({ where: { id } });
        if (!enrollment) {
            return res.status(404).json({ message: "Enrollment not found." });
        }

        // Update the enrollment details
        await enrollment.update({ studentId, courseId });
        res.status(200).json({ message: "Enrollment updated successfully!", enrollment });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to update enrollment." });
    }
};

// Delete an enrollment by ID
const deleteEnrollment = async (req, res) => {
    const { id } = req.params;

    try {
        const enrollment = await Enrollment.findOne({ where: { id } });
        if (!enrollment) {
            return res.status(404).json({ message: "Enrollment not found." });
        }

        // Delete the enrollment
        await enrollment.destroy();
        res.status(200).json({ message: "Enrollment deleted successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to delete enrollment." });
    }
};

module.exports = { createEnrollment, getAllEnrollments, getEnrollmentById, updateEnrollment, deleteEnrollment };
