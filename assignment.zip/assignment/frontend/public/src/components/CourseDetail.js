import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import "./CourseDetail.css";

const CourseDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [course, setCourse] = useState(null);
    const [error, setError] = useState("");
    const [loading, setLoading] = useState(true);
    const [success, setSuccess] = useState("");

    useEffect(() => {
        const fetchCourse = async () => {
            try {
                const response = await axios.get(`http://localhost:5000/api/courses/${id}`);
                setCourse(response.data);
                setLoading(false);
            } catch (error) {
                setError("Failed to fetch course details.");
                setLoading(false);
            }
        };

        fetchCourse();
    }, [id]);

    const handleEnroll = async () => {
        try {
            const token = localStorage.getItem("token");
            if (!token) {
                navigate("/login");
                return;
            }

            const response = await axios.post(
                "http://localhost:5000/api/enrollments",
                { courseId: id },
                { headers: { Authorization: `Bearer ${token}` } }
            );

            if (response.data.success) {
                setSuccess("Successfully enrolled in the course!");
            }
        } catch (error) {
            setError(error.response?.data?.message || "Enrollment failed.");
        }
    };

    if (loading) return <p>Loading course details...</p>;
    if (error) return <p className="error">{error}</p>;

    return (
        <div className="course-detail-container">
            <h2>{course.title}</h2>
            <p>{course.description}</p>
            <p><strong>Instructor:</strong> {course.instructor}</p>
            <p><strong>Duration:</strong> {course.duration} hours</p>
            {success ? (
                <p className="success">{success}</p>
            ) : (
                <button className="enroll-btn" onClick={handleEnroll}>Enroll</button>
            )}
        </div>
    );
};

export default CourseDetail;
