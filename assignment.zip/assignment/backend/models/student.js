const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../db").sequelize;

const Student = sequelize.define("Student", {
    name: { type: DataTypes.STRING, allowNull: false },
    email: { type: DataTypes.STRING, unique: true, allowNull: false },
    courseId: { type: DataTypes.INTEGER, allowNull: false },  // Associate with courses
});

module.exports = Student;
