const express = require("express");
const { register, login, logout } = require("../controllers/authController");
const router = express.Router();

// Register a new user (student/admin)
router.post("/register", register);

// Login a user (student/admin)
router.post("/login", login);

// Logout a user (student/admin)
router.post("/logout", logout);

module.exports = router;
