const express = require("express");
const { authenticateUser, authorizeAdmin } = require("../middleware/authMiddleware");
const { createStudent, getAllStudents, getStudentById, updateStudent, deleteStudent } = require("../controllers/studentController");
const router = express.Router();

// Create a new student (admin only)
router.post("/students", authenticateUser, authorizeAdmin, createStudent);

// Get all students
router.get("/students", getAllStudents);

// Get a student by ID
router.get("/students/:id", getStudentById);

// Update a student by ID (admin only)
router.put("/students/:id", authenticateUser, authorizeAdmin, updateStudent);

// Delete a student by ID (admin only)
router.delete("/students/:id", authenticateUser, authorizeAdmin, deleteStudent);

module.exports = router;
