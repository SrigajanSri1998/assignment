const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const morgan = require("morgan");
const bodyParser = require("body-parser");

// Import routes
const authRoutes = require("./routes/authRoutes");
const courseRoutes = require("./routes/courseRoutes");
const studentRoutes = require("./routes/studentRoutes");
const enrollmentRoutes = require("./routes/enrollmentRoutes");

// Initialize environment variables
dotenv.config();

// Create an instance of Express
const app = express();

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing (CORS)
app.use(morgan("dev")); // HTTP request logger for development
app.use(bodyParser.json()); // Parse incoming request bodies as JSON
app.use(bodyParser.urlencoded({ extended: true })); // For URL-encoded bodies

// API Routes
app.use("/api/auth", authRoutes); // Authentication routes
app.use("/api", courseRoutes); // Course management routes
app.use("/api", studentRoutes); // Student management routes
app.use("/api", enrollmentRoutes); // Enrollment management routes

// Default route
app.get("/", (req, res) => {
  res.send("Welcome to the Online Learning Platform Backend!");
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send("Something went wrong!");
});

// Set the port to listen on
const PORT = process.env.PORT || 5000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
