const express = require("express");
const { authenticateUser, authorizeAdmin } = require("../middleware/authMiddleware");
const { createEnrollment, getAllEnrollments, getEnrollmentById, updateEnrollment, deleteEnrollment } = require("../controllers/enrollmentController");
const router = express.Router();

// Create a new enrollment (admin only)
router.post("/enrollments", authenticateUser, authorizeAdmin, createEnrollment);

// Get all enrollments
router.get("/enrollments", getAllEnrollments);

// Get an enrollment by ID
router.get("/enrollments/:id", getEnrollmentById);

// Update an enrollment by ID (admin only)
router.put("/enrollments/:id", authenticateUser, authorizeAdmin, updateEnrollment);

// Delete an enrollment by ID (admin only)
router.delete("/enrollments/:id", authenticateUser, authorizeAdmin, deleteEnrollment);

module.exports = router;
